

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HelloServlet
 */
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor. 
	 */
	public HelloServlet() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		/*
		*
		*
		*Basic
		*
		*/
		
		/*String name = request.getParameter("user");

		ServletConfig config = getServletConfig();
		String user = config.getInitParameter("username");
		String pwd = config.getInitParameter("password");

		ServletContext context = getServletContext();
		String path = context.getInitParameter("database path");

		PrintWriter pw = response.getWriter();
		pw.print("<b>Welcome " + name + " to my first web application </b> <br>");
		pw.print("User : " + user + "<br> Password: " + pwd);
		pw.print("<br>DB Path: " + path );
		pw.close();*/
		
		
		/*
		*
		*
		*HTML + Database
		*
		*/
		
		/*Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		PrintWriter pw=null;
		
		int id = Integer.parseInt(request.getParameter("empid"));
		
		try 
		{
			//Load the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");
			
			//Get the connection
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");
			
			st=con.createStatement();
			
			String query = "select * from emp where id="+id;
			rs=st.executeQuery(query);
			
			pw = response.getWriter();
			
			while(rs.next())
			{
				int eid=rs.getInt(1);
				String n=rs.getString(2);
				String d=rs.getString(3);
				pw.print("<h1>" + eid + " : " + n + " : " + d + "</h1>");
			}
			
			rs.close();
			st.close();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				pw.close();
				con.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
		}*/
		
		PrintWriter pw = response.getWriter();
		pw.print("Employee Confirmation ");
		pw.close();
		
		int id = Integer.parseInt(request.getParameter("empid"));
		
		if( (id>=101) && (id<=105))
		{
			//valid user
			RequestDispatcher rd=request.getRequestDispatcher("/Second");
			rd.include(request, response);
		}
		else 
		{
			//invalid user
			/*pw.print("Invalid employee");
			pw.close();*/
			response.sendRedirect("https://www.google.com");
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
