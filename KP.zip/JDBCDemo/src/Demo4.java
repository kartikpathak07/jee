import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Demo4 
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		try 
		{
			//Load the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");

			//Get the connection
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");

			PreparedStatement pspmt=conn.prepareStatement("insert into emp values(?,?,?)");

			pspmt.setInt(1,105);  
			pspmt.setString(2,"Ajay");
			pspmt.setString(3,"HR");
			pspmt.execute();
			System.out.println("Record inserted successfully");

		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
