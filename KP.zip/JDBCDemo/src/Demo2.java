import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class Demo2 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		try 
		{
			//Load the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");
			
			//Get the connection
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");
			
			Statement st=con.createStatement();
			
			System.out.print("Enter Employee ID : ");
			int eid=sc.nextInt();
			System.out.print("Enter Employee name : ");
			String name=sc.next();
			System.out.print("Enter Employee department : ");
			String dept=sc.next();
			
			String insert="insert into emp values ("+eid+",'"+name+"','"+dept+"')";
			st.execute(insert);
			
			String display="select * from emp";
						
			ResultSet rs=st.executeQuery(display);
			
			while(rs.next())
			{
				int id=rs.getInt(1);
				String n=rs.getString(2);
				String d=rs.getString(3);
				System.out.println(id + ":" + n + ":" + d);
			}
			
			rs.close();
			st.close();
			
			
			
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
