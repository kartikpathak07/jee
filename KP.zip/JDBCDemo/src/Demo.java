import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Demo 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		try 
		{
			//Load the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");
			
			//Get the connection
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");
			
			Statement st=con.createStatement();
			
			String query = "select * from emp";
			ResultSet rs=st.executeQuery(query);
			
			while(rs.next())
			{
				int id=rs.getInt(1);
				String n=rs.getString(2);
				String d=rs.getString(3);
				System.out.println(id + ":" + n + ":" + d);
			}
			
			rs.close();
			st.close();
		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

//create table customer(customerID number(10), name varchar2(30), contact number(10), address varchar2(30), date_of_birth date);
