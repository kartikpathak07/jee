import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;


public class Demo5 
{
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		try 
		{
			//Load the driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");

			//Get the connection
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");

			CallableStatement cst = conn.prepareCall("{call addition(?,?,?)}");
			cst.setInt(1, 10);
			cst.setInt(2, 20);
			cst.registerOutParameter(3, Types.INTEGER);
			cst.execute();

			System.out.println("Addition: " + cst.getInt(3));

		}
		catch (ClassNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
