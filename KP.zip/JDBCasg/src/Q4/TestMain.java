package Q4;

import java.sql.Date;
import java.util.Scanner;

public class TestMain
{

	@SuppressWarnings("deprecation")
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Operations o=new Operations();
		Customer c=new Customer();
		boolean flag=false;
		while(true)
		{
			System.out.println("------------------MENU------------------");
			System.out.println("1. Insert new Customer details");
			System.out.println("2. Update the customer details");
			System.out.println("3. Delete the customer record");
			System.out.println("4. Display all customer details");
			System.out.println("5. Exit");

			System.out.print("Enter your choice : ");
			int ch=sc.nextInt();

			switch (ch) 
			{
			case 1:
			{
				System.out.print("Enter customer ID : ");
				int custId=sc.nextInt();
				System.out.print("Enter customer name : ");
				String name=sc.next();
				System.out.print("Enter contact number : ");
				long contact=sc.nextLong();
				System.out.print("Enter address : ");
				String address=sc.next();
				System.out.print("Enter date of birth (DD-MM-YYYY) : ");
				String date=sc.next();
				String d[]=date.split("-");
				Date dt=new Date((Integer.parseInt(d[2])-1900), (Integer.parseInt(d[1])-1), Integer.parseInt(d[0]));
				c.setCustomerId(custId);
				c.setName(name);
				c.setContactNo(contact);
				c.setAddress(address);
				c.setDateOfBirth(dt);
				o.insert(c);
				break;
			}

			case 2:
			{
				System.out.print("Enter customer ID whose data has to be updated : ");
				int custId=sc.nextInt();
				System.out.println("How many parameterts need to be updated ?");
				int j=sc.nextInt();
				for (int i = 1; i <= j; i++) 
				{
					System.out.println("What data has to be updated?");
					System.out.println("1. Customer ID");
					System.out.println("2. Name");
					System.out.println("3. Contact");
					System.out.println("4. Address");
					System.out.println("5. Date of Birth");
					System.out.println("Enter choice : ");
					int key=sc.nextInt();
					switch (key) 
					{
					case 1:
					{
						System.out.print("Enter new customer ID : ");
						c.setCustomerId(sc.nextInt());
						o.update(c, custId, 1);
						break;
					}

					case 2:
					{
						System.out.print("Enter new name : ");
						c.setName(sc.next());
						o.update(c, custId, 2);
						break;
					}

					case 3:
					{
						System.out.print("Enter new contact : ");
						c.setContactNo(sc.nextLong());
						o.update(c, custId, 3);
						break;
					}

					case 4:
					{
						System.out.print("Enter new address : ");
						c.setAddress(sc.next());
						o.update(c, custId, 4);
						break;
					}

					case 5:
					{
						System.out.print("Enter new date of birth (DD-MM-YYYY) : ");
						String date=sc.next();
						String d[]=date.split("-");
						Date dt=new Date((Integer.parseInt(d[2])-1900), (Integer.parseInt(d[1])-1), Integer.parseInt(d[0]));
						c.setDateOfBirth(dt);
						o.update(c, custId, 5);
						break;
					}

					default:
					{
						System.out.println("Invalid choice");
						break;
					}
					}
				}

				break;
			}

			case 3:
			{
				System.out.print("Enter customer ID to be deleted : ");
				int custId=sc.nextInt();
				o.delete(custId);
				break;
			}

			case 4:
			{
				o.display();
				break;
			}

			case 5:
			{
				flag=true;
				break;
			}



			default:
			{
				System.err.println("Invalid choice");
				break;
			}
			}
			if(flag)
			{
				System.out.println("************Exiting Application************");
				break;
			}
		}


	}

}
