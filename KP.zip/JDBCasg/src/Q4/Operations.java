package Q4;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

public class Operations 
{
	MyDBConnection mdb=new MyDBConnection();
	PreparedStatement pst;
	Connection conn;
	
	public void insert(Customer c) 
	{
		conn=mdb.DBConn();
		
		try 
		{
			pst=conn.prepareStatement("insert into customer values(?,?,?,?,?)");
			pst.setInt(1, c.getCustomerId());
			pst.setString(2, c.getName());
			pst.setLong(3, c.getContactNo());
			pst.setString(4, c.getAddress());
			pst.setDate(5,(Date) c.getDateOfBirth());
			pst.execute();
			System.out.println("Record successfully added!!!");
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		finally
		{
			try
			{
				pst.close();
				conn.close();
			}
			catch (SQLException e)
			{ 
				e.printStackTrace();
			}
			
		}
	}
	
	public void update(Customer c,int cid, int ch) 
	{
		conn=mdb.DBConn();
		
		if(ch==1)
		{
			try 
			{
				pst=conn.prepareStatement("update customer set customerID=? where customerID=?");
				pst.setInt(1, c.getCustomerId());
				pst.setInt(2, cid);
				pst.execute();
				System.out.println("Record updated successfully!!!");
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					pst.close();
					conn.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		else if(ch==2)
		{
			try 
			{
				pst=conn.prepareStatement("update customer set name=? where customerID=?");
				pst.setString(1, c.getName());
				pst.setInt(2, cid);
				pst.execute();
				System.out.println("Record updated successfully!!!");
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					pst.close();
					conn.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		else if(ch==3)
		{
			try 
			{
				pst=conn.prepareStatement("update customer set contact=? where customerID=?");
				pst.setLong(1, c.getContactNo());
				pst.setInt(2, cid);
				pst.execute();
				System.out.println("Record updated successfully!!!");
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					pst.close();
					conn.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		else if(ch==4)
		{
			try 
			{
				pst=conn.prepareStatement("update customer set address=? where customerID=?");
				pst.setString(1, c.getAddress());
				pst.setInt(2, cid);
				pst.execute();
				System.out.println("Record updated successfully!!!");
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					pst.close();
					conn.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		else
		{
			try 
			{
				pst=conn.prepareStatement("update customer set date_of_birth=? where customerID=?");
				pst.setDate(1, (Date) c.getDateOfBirth());
				pst.setInt(2, cid);
				pst.execute();
				System.out.println("Record updated successfully!!!");
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					pst.close();
					conn.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}
	
	public void delete(int custId) 
	{
		conn=mdb.DBConn();
		
		try 
		{
			pst=conn.prepareStatement("delete from customer where customerID=?");
			pst.setInt(1, custId);
			pst.execute();
			System.out.println("Record successfully deleted!!!");
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("deprecation")
	public void display() 
	{
		conn=mdb.DBConn();
		ResultSet rs = null;
		
		try {
			pst = conn.prepareStatement("select * from customer");
			rs=pst.executeQuery();
			System.out.println("Record is displayed as follows : ");
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				long contact=rs.getLong(3);
				String address=rs.getString(4);
				Date d=rs.getDate(5);
				
				int dt=d.getDate();
				int m=(d.getMonth()+1);
				int y=(d.getYear()+1900);
				System.out.println(id + " : " + name + " : " + contact + " : " + address + " : " + dt + "-" + m + "-" + y);
			}
			
			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			try {
				rs.close();
				pst.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
	}
	
}
