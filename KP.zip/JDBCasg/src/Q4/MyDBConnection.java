package Q4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyDBConnection 
{
	public Connection DBConn() 
	{
		try {

			//Load Class
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");

			//Get the connection
			Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");
			
			return conn;
			
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			return null;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}

	}

}
