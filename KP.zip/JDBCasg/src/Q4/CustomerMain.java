package Q4;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerMain
{
	MyDBConnection mdb=new MyDBConnection();
	PreparedStatement pst;
	Connection conn;

	public void display() 
	{
		conn=mdb.DBConn();
		ResultSet rs=null;
		
		
		try 
		{
			pst=conn.prepareStatement("select name, address from customer");
			rs=pst.executeQuery();
			System.out.println(" Name  :  Address ");
			while(rs.next())
			{
				System.out.println(rs.getString(1) + " : " + rs.getString(2));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}

		}
	}

	@SuppressWarnings("deprecation")
	public void display(String address) 
	{
		conn=mdb.DBConn();
		ResultSet rs=null;
		
		try 
		{
			pst=conn.prepareStatement("select * from customer where address=?");
			pst.setString(1, address);
			rs=pst.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getInt(1) + " : " + rs.getString(2) + " : " + rs.getLong(3) + " : " + rs.getString(4) + " : " + 
						(rs.getDate(5).getDate()) + "-" + (rs.getDate(5).getMonth()+1) + "-" + (rs.getDate(5).getYear()+1900));
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

	public int disp(String address) 
	{
		conn=mdb.DBConn();
		ResultSet rs=null;
		try 
		{
			pst=conn.prepareStatement("select count(*) from customer where address=?");
			pst.setString(1, address);
			rs=pst.executeQuery();
			rs.next();
			return rs.getInt(1);

		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return 0;
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	@SuppressWarnings("deprecation")
	public void display(int year) 
	{
		conn=mdb.DBConn();
		ResultSet rs=null;
		
		try 
		{
			pst=conn.prepareStatement(" select * from customer where to_char(date_of_birth,'YYYY')=?");
			pst.setInt(1, year);
			rs=pst.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getInt(1) + " : " + rs.getString(2) + " : " + rs.getLong(3) + " : " + rs.getString(4) + " : " + 
						(rs.getDate(5).getDate()) + "-" + (rs.getDate(5).getMonth()+1) + "-" + (rs.getDate(5).getYear()+1900));
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}

		}
	}


	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		CustomerMain cm=new CustomerMain();
		cm.display();
		System.out.print("Enter address : ");
		String address=sc.next();
		cm.display(address);
		int count=cm.disp(address);
		System.out.println(count);
		System.out.print("Enter year : ");
		cm.display(sc.nextInt());
	}

}
