package Q4;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class CustomerInfo 
{
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) 
	{
		Connection conn;
		MyDBConnection mdb=new MyDBConnection();
		conn=mdb.DBConn();
		ResultSet rs = null;
		PreparedStatement pst=null;
		ResultSetMetaData rsmd=null;
		try {
			pst = conn.prepareStatement("select * from customer");
			rs=pst.executeQuery();
			System.out.println("Record is displayed as follows : ");
			while(rs.next())
			{
				int id=rs.getInt(1);
				String name=rs.getString(2);
				long contact=rs.getLong(3);
				String address=rs.getString(4);
				Date d=rs.getDate(5);
				
				int dt=d.getDate();
				int m=(d.getMonth()+1);
				int y=(d.getYear()+1900);
				System.out.println(id + " : " + name + " : " + contact + " : " + address + " : " + dt + "-" + m + "-" + y);
			}
			
			rsmd=rs.getMetaData();
			
			System.out.println("Total number of columns : " + rsmd.getColumnCount());
			System.out.println("The column names are ");
			for(int i=1;i<=rsmd.getColumnCount();i++)
				System.out.println(i + " is " + rsmd.getColumnName(i) + " with datatype " + rsmd.getColumnTypeName(i) + "(" + rsmd.getColumnDisplaySize(i) + ")");
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			try {
				rs.close();
				pst.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
