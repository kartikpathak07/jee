package Q3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class EmployeeDet 
{
	static Connection con;
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		EmployeeDet ed=new EmployeeDet();
		ed.DBConn();
		System.out.print("Enter employee id to be fetched : ");
		int eid=sc.nextInt();
		System.out.println("Name of employee is : "+ed.proc_empname(eid));
	}
	
	public String proc_empname (int empno) 
	{
		try 
		{
			Statement st=con.createStatement();
			String query="select name from emp where id="+empno;
			
			ResultSet rs=st.executeQuery(query);
			rs.next();
			return rs.getString(1);
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return "Error";
		}		
	}
	
	public void DBConn() 
	{
		try {

			//Load Class
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");

			//Get the connection
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

	}
}
