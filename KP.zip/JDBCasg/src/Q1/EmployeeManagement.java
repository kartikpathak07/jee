package Q1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class EmployeeManagement 
{
	static Connection con;

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		EmployeeManagement em=new EmployeeManagement();

		boolean flag=false;
		em.DBConn();

		while(true)
		{
			System.err.println("---------MENU---------");
			System.out.println("1.Display All Employees");
			System.out.println("2.Display First Employee");
			System.out.println("3.Display Last Employee");
			System.out.println("4.Display All Departments");
			System.out.println("5.Display First Department");
			System.out.println("6.Display Last Department");
			System.out.println("7.Exit");

			System.out.print("Enter your choice (1-7) : ");
			int ch=sc.nextInt();
			switch (ch) 
			{
			case 1:
			{
				Statement st;
				try {
					st = con.createStatement();
					String query = "select * from emp";
					ResultSet rs=st.executeQuery(query);

					while(rs.next())
					{
						int id=rs.getInt(1);
						String n=rs.getString(2);
						String d=rs.getString(3);
						System.out.println(id + ":" + n + ":" + d);
					}
					rs.close();
					st.close();
					break;
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			case 2:
			{
				Statement st;
				try {
					st = con.createStatement();
					String query = "select * from emp";
					ResultSet rs=st.executeQuery(query);

					rs.next();
					int id=rs.getInt(1);
					String n=rs.getString(2);
					String d=rs.getString(3);
					System.out.println(id + ":" + n + ":" + d);

					rs.close();
					st.close();
					break;
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			case 3:
			{
				Statement st;
				try {
					st = con.createStatement();
					String query = "select * from emp";
					ResultSet rs=st.executeQuery(query);

					int id=0;
					String n=null;
					String d=null;
					while(rs.next())
					{
						id=rs.getInt(1);
						n=rs.getString(2);
						d=rs.getString(3);

					}
					System.out.println(id + ":" + n + ":" + d);

					rs.close();
					st.close();
					break;
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			case 4:
			{
				Statement st;
				try {
					st = con.createStatement();
					String query = " select distinct dept from emp";
					ResultSet rs=st.executeQuery(query);

					while(rs.next())
					{
						String d=rs.getString(1);
						System.out.println(d);
					}
					rs.close();
					st.close();
					break;
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			case 5:
			{
				Statement st;
				try {
					st = con.createStatement();
					String query = " select distinct dept from emp";
					ResultSet rs=st.executeQuery(query);

					rs.next();
					
						String d=rs.getString(1);
						System.out.println(d);
					
					rs.close();
					st.close();
					break;
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			case 6:
			{
				Statement st;
				try {
					st = con.createStatement();
					String query = " select distinct dept from emp";
					ResultSet rs=st.executeQuery(query);

					String d=null;
					while(rs.next())
					{
						d=rs.getString(1);
					}
					System.out.println(d);
					rs.close();
					st.close();
					break;
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			case 7:
			{
				flag=true;
				break;
			}
			default:
			{
				System.err.println("Invalid Choice");
				break;
			}
			}
			if(flag)
			{
				break;
			}
		}
		sc.close();
	}

	public void DBConn() 
	{
		try {

			//Load Class
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println("Driver loaded successfully!!!!");

			//Get the connection
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			System.out.println("Connection established!!");
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

	}
}
