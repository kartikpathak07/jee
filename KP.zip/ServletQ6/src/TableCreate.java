import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class TableCreate 
{
	public void createTable() 
	{
		MyDBConn mdbc=new MyDBConn();
		Connection conn=null;
		PreparedStatement ps=null;
		
		try 
		{
			conn=mdbc.getConnection();
			ps=conn.prepareStatement("create table Login(username varchar2(20) primary key, password varchar2(20) not null");
			ps.execute();
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				ps.close();
				conn.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
		}
	}
}
