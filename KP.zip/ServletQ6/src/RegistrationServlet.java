

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uname=request.getParameter("username");
		String pwd=request.getParameter("password");
		
		MyDBConn mdbc=new MyDBConn();
		TableCreate tc=new TableCreate();
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		PrintWriter pw=response.getWriter();
		RequestDispatcher rd=null;
		
		try 
		{
			conn=mdbc.getConnection();
			ps=conn.prepareStatement("select count(*) from tab where tname=?");
			ps.setString(1, "login");
			rs=ps.executeQuery();
			if(rs.getInt(1)==0)
			{
				tc.createTable();
				rs.close();
			}
			ps=conn.prepareStatement("insert into login values(?,?)");
			ps.setString(1, uname);
			ps.setString(2, pwd);
			if(ps.execute())
			{
				pw.print("Registration successful!!!");
			}
			else
			{
				pw.print("Registration not successful!! Try again");
				rd=request.getRequestDispatcher("registration");
				rd.include(request, response);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				ps.close();
				pw.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
