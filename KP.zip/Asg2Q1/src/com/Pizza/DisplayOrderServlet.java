package com.Pizza;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayOrderServlet
 */
public class DisplayOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int order_no=(Integer) request.getAttribute("order_no");
		
		ServletConfig sc=getServletConfig();
		String driver=sc.getInitParameter("driver");
		String url=sc.getInitParameter("url");
		String portno=sc.getInitParameter("portno");
		String databasename=sc.getInitParameter("databasename");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
		
		LoginServlet ls=new LoginServlet();
		PrintWriter pw=response.getWriter();
		
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		
		try {
			conn = ls.getConnection(driver, url, portno, databasename, username, password);
			ps=conn.prepareStatement("select * from order_pizza where order_no=?");
			ps.setInt(1, order_no);
			rs=ps.executeQuery();
			rs.next();
			
			pw.print("<html> <table border=1> <tr> <th> Order Number </th><th> Pizza Type </th><th> No of Pizza </th> </tr>");
			pw.print("<tr> <td>"+ rs.getInt(1)  +"</td><td>"+ rs.getString(2)  +"</td><td>"+ rs.getInt(3)  +"</td></tr></table>");
			
			RequestDispatcher rd=request.getRequestDispatcher("After_disp.html");
			rd.include(request, response);
			
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				ps.close();
				rs.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
