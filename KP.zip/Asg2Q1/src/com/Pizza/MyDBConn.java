package com.Pizza;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyDBConn
 */
public class MyDBConn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyDBConn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServletConfig sc=getServletConfig();
		String driver=sc.getInitParameter("driver");
		String url=sc.getInitParameter("url");
		String portno=sc.getInitParameter("portno");
		String databasename=sc.getInitParameter("databasename");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
		
		getConnection(driver, url, portno, databasename, username, password);
		
		RequestDispatcher rd=request.getRequestDispatcher("Login");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	public Connection getConnection(String driver, String url, String portno, String databasename, String username, String password) 
	{
		try {
			
			//Load Class
			Class.forName(driver);
			System.out.println("Driver loaded successfully!!!!");

			//Get the connection
			//Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
			Connection conn=DriverManager.getConnection(url+portno+databasename,username,password); 
			System.out.println("Connection established!!");
			
			return conn;
			
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			return null;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return null;
		}
	}

}
