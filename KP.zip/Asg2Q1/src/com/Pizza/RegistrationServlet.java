package com.Pizza;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegistrationServlet
 */
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegistrationServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		ServletConfig sc=getServletConfig();
		LoginServlet ls=new LoginServlet();
		
		String driver=sc.getInitParameter("driver");
		String url=sc.getInitParameter("url");
		String portno=sc.getInitParameter("portno");
		String databasename=sc.getInitParameter("databasename");
		String username=sc.getInitParameter("username");
		String password=sc.getInitParameter("password");
		String uname=request.getParameter("username");
		String pwd=request.getParameter("password");

		
		Connection conn=null;
		PreparedStatement ps=null;
		PrintWriter pw=response.getWriter();
		RequestDispatcher rd=null;

		try 
		{
			conn = ls.getConnection(driver, url, portno, databasename, username, password);
			ps=conn.prepareStatement("insert into login values(?,?)");
			ps.setString(1, uname);
			ps.setString(2, pwd);
			ps.executeUpdate();
			ps.close();
			pw.print("<html> Registration successful!!!");
			rd=request.getRequestDispatcher("login.html");
			rd.include(request, response);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				ps.close();
				pw.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
