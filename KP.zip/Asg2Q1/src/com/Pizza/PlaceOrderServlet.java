package com.Pizza;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PlaceOrderServlet
 */
public class PlaceOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PlaceOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int quant=Integer.parseInt(request.getParameter("no_of_pizza"));
		String type=request.getParameter("pizza_type");
		PrintWriter pw=response.getWriter();
		
		pw.print(type);
		
		if(quant<1)
		{
			pw.write("Invalid quantity");
			response.sendRedirect("orderPizza.html");
		}
		else 
		{
			ServletConfig sc=getServletConfig();
			String driver=sc.getInitParameter("driver");
			String url=sc.getInitParameter("url");
			String portno=sc.getInitParameter("portno");
			String databasename=sc.getInitParameter("databasename");
			String username=sc.getInitParameter("username");
			String password=sc.getInitParameter("password");
			
			LoginServlet ls=new LoginServlet();
						
			Connection conn=null;
			PreparedStatement ps=null;
			ResultSet rs=null;
			int ch=0;
			RequestDispatcher rd=null;
			
			try {
				conn = ls.getConnection(driver, url, portno, databasename, username, password);
				ps=conn.prepareStatement("select max(order_no) from order_pizza");
				rs=ps.executeQuery();
				rs.next();
				ch=rs.getInt(1);
				ch++;
				ps=conn.prepareStatement("insert into order_pizza values(?,?,?)");
				ps.setInt(1, ch);
				ps.setString(2, type);
				ps.setInt(3, quant);
				ps.executeUpdate();
				pw.print("Order placed!!");
				request.setAttribute("order_no", new Integer(ch));
				rd=request.getRequestDispatcher("DisplayOrder");
				rd.forward(request, response);
				
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try
				{
					conn.close();
					ps.close();
					rs.close();
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
